//Imports
import { spawn } from 'child_process';
import findRemoveSync from 'find-remove';
import { BACKUP_ROUTE, MONGODB_URI } from "./config.js";

//Función encargada de extraer backups
export function backupMongoDB() {
//Definición de constantes en base a la fecha actual del equipo
const currentDate = new Date();
//Definicion de constantes
const DB_NAME = 'test';
const fileDate = `${currentDate.toDateString()} ${currentDate.getHours()}`;
const filePath = BACKUP_ROUTE;
  const child = spawn('mongodump', [
    `--db=${DB_NAME}`,
    `--uri=${MONGODB_URI}`,
    `--archive=${filePath}${DB_NAME}-${fileDate}.gzip`,
    '--gzip',
  ]);

  child.stdout.on('data', (data) => {
    console.log('stdout:\n', data);
  });
  child.stderr.on('data', (data) => {
    console.log('stderr:\n', Buffer.from(data).toString());
  });
  child.on('error', (error) => {
    console.log('error:\n', error);
  });
  child.on('exit', (code, signal) => {
    if (code) console.log('Process exit with code:', code);
    else if (signal) console.log('Process killed with signal:', signal);
    else console.log('Backup succesfully created');
  });
  
}

//Función encargada de eliminar backups modificados hace más de 2 semanas
export function autodelete(){
    findRemoveSync(filePath, {age: { seconds: 1209600 },
      extensions: ".gzip"});
}
