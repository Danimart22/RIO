export const MONGODB_URI = process.env.MONGODB_URI || "mongodb://localhost:27017/";
export const PORT = process.env.PORT || 4000;
export const SECRET = "empleado-api";
export const BACKUP_ROUTE = process.env.BACKUP_ROUTE;
export const SES_KEY = process.env.SES_KEY;
export const SES_SECRETEKEY = process.env.SES_SECRETEKEY;