import User from "../models/User.js";
import jwt from "jsonwebtoken";
import { SECRET } from "../config.js";
import Roles from "../models/Roles.js";
import nodemailer from "nodemailer";
import {SES_KEY, SES_SECRETEKEY} from "../config.js"

const transporter = nodemailer.createTransport({
  host: "email-smtp.us-east-1.amazonaws.com",
  port: 465,
  secure: true,
  auth: {
    user: SES_KEY,
    pass: SES_SECRETEKEY,
  },
})

export const signUp = async (req, res) => {
  const {
    username,
    documento,
    tipo_documento,
    nombres,
    apellidos,
    correo,
    sangre,
    telefono,
    acudiente,
    tipo_acudiente,
    numero_acudiente,
    direccion,
    eps,
    arl,
    password,
    enfermedades,
    alergias,
    fechas_reserva,
    estado,
    brigadista,
    roles,
  } = req.body;

  const currentDate = new Date(); // Obtener la fecha actual
  const fecha = currentDate.toLocaleString("es-ES", {
    timeZone: "America/Bogota",
  });

  const encryptedPassword = password || documento.toString(); // Establecer contraseña predeterminada

  const newUser = new User({
    username,
    tipo_documento,
    documento,
    nombres,
    apellidos,
    correo,
    sangre,
    telefono,
    acudiente,
    tipo_acudiente,
    numero_acudiente,
    direccion,
    eps,
    arl,
    password: await User.encryptPassword(encryptedPassword),
    enfermedades,
    alergias,
    estado: estado || "activo",
    brigadista: brigadista || "No", // Agregar el campo brigadista
  });

  if (roles) {
    const foundRoles = await Roles.find({ nombre: { $in: roles } });
    newUser.roles = foundRoles.map((role) => role._id);
  } else {
    const role = await Roles.findOne({ nombre: "empleado" });
    newUser.roles = [role._id];
  }

  const savedUser = await newUser.save();

  const token = jwt.sign({ id: savedUser._id }, SECRET, {
    expiresIn: 86400, // tiempo en segundos para expirar la sesión
  });

  const htmlContent = `
<html>
  <body>
    <h1>Bienvenido a Mobilize Financial Service</h1>
    <p>Tu usuario ha sido creado exitosamente, recuerda cambiar la contraseña al iniciar sesion</p>
    <p>Tu Correo es: ${correo}</p>
    <p>Tu contraseña es: ${password}</p>
  </body>
</html>
`;

const mailOptions = {
  from: 'rio@rci.colombia.com',
  to: savedUser.correo, // Correo del usuario recién registrado
  subject: '¡Registro exitoso!',
  html: htmlContent,
};

transporter.sendMail(mailOptions, (error, info) => {
  if (error) {
    console.error('Error al enviar el correo electrónico:', error);
  } else {
    console.log('Correo electrónico enviado:', info.response);
  }
});


  res.status(200).json({ token });
};

export const signUpImport = async (req, res) => {
  try {
    const usersData = req.body;

    // Validar que se proporcionó una lista de usuarios
    if (!Array.isArray(usersData)) {
      return res
        .status(400)
        .json({ message: "La solicitud debe contener una lista de usuarios." });
    }

    const savedUsers = [];
    const errorUsers = [];

    for (const userData of usersData) {
      const existingUserCorreo = await User.findOne({
        correo: userData.correo,
      });
      const existingUserDocumento = await User.findOne({
        documento: userData.documento,
      });

      if (existingUserCorreo) {
        errorUsers.push({
          message: `Ya existe otro usuario con el correo: ${userData.correo}`,
        });
        continue;
      }

      if (existingUserDocumento) {
        errorUsers.push({
          message: `Ya existe otro usuario con el documento: ${userData.documento}`,
        });
        continue;
      }

      const {
        nombres,
        apellidos,
        username,
        tipo_documento,
        documento,
        correo,
        sangre,
        telefono,
        acudiente,
        tipo_acudiente,
        numero_acudiente,
        direccion,
        eps,
        arl,
        password,
        enfermedades,
        alergias,
        fechas_reserva,
        estado,
        brigadista,
        roles,
      } = userData;

      const currentDate = new Date();
      const fecha = currentDate.toLocaleString("es-ES", {
        timeZone: "America/Bogota",
      });

      const encryptedPassword =
        password || (documento ? documento.toString() : "");

      const generatedUsername =
        username || generateUsername(nombres, apellidos);

      const newUser = new User({
        username: generatedUsername,
        tipo_documento,
        documento,
        nombres,
        apellidos,
        correo,
        sangre,
        telefono,
        acudiente,
        tipo_acudiente,
        numero_acudiente,
        direccion,
        eps,
        arl,
        password: await User.encryptPassword(encryptedPassword),
        enfermedades,
        alergias,
        estado: estado || "activo",
        brigadista: brigadista || "No",
      });

      if (roles) {
        const foundRoles = await Roles.find({ nombre: { $in: roles } });
        newUser.roles = foundRoles.map((role) => role._id);
      } else {
        const role = await Roles.findOne({ nombre: "empleado" });
        newUser.roles = [role._id];
      }

      const savedUser = await newUser.save();
      savedUsers.push(savedUser);
    }

    res.status(200).json({ users: savedUsers, errorUsers });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: "Error al crear los usuarios." });
  }
};

function generateUsername(firstName, lastName) {
  const firstNameLower = firstName.toLowerCase().split(" ")[0];
  const lastNameLower = lastName.toLowerCase().split(" ")[0];
  return `${firstNameLower}_${lastNameLower}`;
}

export const signin = async (req, res) => {
  try {
    const userFound = await User.findOne({ correo: req.body.correo }).populate(
      "roles"
    );
    if (!userFound)
      return res.status(400).json({ message: "No se encontró correo asociado" });

    if (userFound.estado !== "activo")
      return res.status(401).json({
        token: null,
        message:
          "Usuario inactivo. Pide a un administrador que reactive tu cuenta",
      });

    const matchPassword = await User.comparePassword(
      req.body.password,
      userFound.password
    );

    if (!matchPassword)
      return res.status(401).json({ token: null, message: "Contraseña incorrecta, la contraseña que se ingresó es incorrecta" });

      const tokenExpiration = new Date();
      tokenExpiration.setHours(tokenExpiration.getHours() + 1); 
      
      const token = jwt.sign({ id: userFound._id, expiry: tokenExpiration }, SECRET, {
        expiresIn: "1h",
      });
    res.json({
      token,
      role: userFound.roles.map((role) => role.nombre),
      id: userFound._id,
      username: userFound.username,
      nombres: userFound.nombres,
      apellidos: userFound.apellidos,
      helpers: userFound.brigadista,
      seatPass: userFound.asiento,
      documento: userFound.documento
    });
  } catch (error) {
    console.error("Error en la autenticación:", error);
    return res.status(500).json({ message: "Error en la autenticación" });
  }
};
