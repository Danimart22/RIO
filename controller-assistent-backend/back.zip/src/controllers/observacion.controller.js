import Observaciones from "../models/Observaciones.js";
import User from "../models/User.js"; // Importamos el modelo de usuario
import nodemailer from "nodemailer";
import mongoose from "mongoose";
import {SES_KEY, SES_SECRETEKEY} from "../config.js"

const transporter = nodemailer.createTransport({
  host: "email-smtp.us-east-1.amazonaws.com",
  port: 465,
  secure: true,
  auth: {
    user: SES_KEY,
    pass: SES_SECRETEKEY,
  },
})

export const createObservacion = async (req, res) => {
  try {
    let {
      fecha,
      asientoReportado,
      observaciones,
      objetos: {
        objeto,
        estado,
        tipo,
      },
    } = req.body;

    // Validación de campos requeridos
    if (!fecha || !asientoReportado || (!objeto)) {
      return res.status(400).json({
        message: "Todos los campos requeridos deben ser proporcionados, incluyendo al menos un objeto faltante o dañado.",
      });
    }

    // Validación del estado
    if (estado && !["activo", "resuelto"].includes(estado)) {
      return res.status(400).json({ message: "El estado debe ser 'activo' o 'resuelto'." });
    }

    //Validación del tipo
    if (tipo && tipo.includes(["faltante", "dañado"])) {
      return res.status(400).json({ message: "El tipo debe ser 'faltante' o 'dañado'." });
    }

    // Validación de objetos
    const validObjetos = [
      "Pantalla", "Teclado", "Mouse", "Descansa pies", "Silla", "Hub adaptador USB", "Cable de video HDMI", "Otros",
    ];

    const invalidFaltantes = validObjetos.filter(ob => objeto.includes(ob));
    if (invalidFaltantes.length <= 0) {
      return res.status(400).json({ message: `Los siguientes objetos no son válidos: ${invalidFaltantes.join(", ")}` });
    }


    // Obtener el usuario reportante
    const usuarioReportanteId = req.userId;
    const usuarioReportante = await User.findById(usuarioReportanteId);
    if (!usuarioReportante) {
      return res.status(404).json({ message: "Usuario no encontrado." });
    }

    // Crear nueva observación
    const nuevaObservacion = new Observaciones({
      fecha,
      asientoReportado,
      observaciones,
      objetos: objeto.map((item, index) => ({
        objeto: item,         // Cada elemento del arreglo 'objeto'
        estado: estado || 'activo',  // Asignar el valor de 'estado', con valor por defecto 'activo'
        tipo: tipo[index]  // Asignar el valor de 'tipo', con valor por defecto 'desconocido'
      })),
      usuarioReportante: { id: usuarioReportante._id, nombreReportante: `${usuarioReportante.nombres} ${usuarioReportante.apellidos}` },
    });


    // Guardar observación
    const observacionGuardada = await nuevaObservacion.save();

    // Función para enviar correos
    const enviaCorreo = async (to, subject, text) => {
      try {
        await transporter.sendMail({ from: "rio@rci-colombia.com", to, subject, text });
        console.log(`Correo enviado a ${to} con el asunto: ${subject}`);
      } catch (error) {
        console.error(`Error al enviar correo a ${to}:`, error);
      }
    };

    // Correo de confirmación
    await enviaCorreo(usuarioReportante.correo, "Nuevo reporte de objeto", `Se ha creado un nuevo reporte para el asiento ${asientoReportado}.`);

    // Envío de correos para objetos faltantes y dañados agrupados
    const electronicos = ["Pantalla", "Teclado", "Mouse", "Hub adaptador USB", "Cable de video HDMI"];
    const mobiliario = ["Descansa pies", "Silla", "Otros"];
    let objFaltantes = [...objeto];
    objFaltantes = objFaltantes.filter((item, idx) => tipo[idx] === "faltante");
    let objDanados = [...objeto];
    objDanados = objDanados.filter((item, idx) => tipo[idx] === "dañado");

    console.log(objDanados);
    console.log(objFaltantes);
    // Inicializar listas para correos
    // Filtrar elementos faltantes electrónicos
    let elementosElectronicosFaltantes = [...objFaltantes];
    elementosElectronicosFaltantes = elementosElectronicosFaltantes.filter((item) => electronicos.includes(item));

    // Filtrar elementos dañados electrónicos
    let elementosElectronicosDanados = [...objDanados];
    elementosElectronicosDanados = elementosElectronicosDanados.filter((item) => electronicos.includes(item));

    // Filtrar elementos faltantes de mobiliario
    let elementosMobiliarioFaltantes = [...objFaltantes];
    elementosMobiliarioFaltantes = elementosMobiliarioFaltantes.filter((item) => mobiliario.includes(item));

    // Filtrar elementos dañados de mobiliario
    let elementosMobiliarioDanados = [...objDanados];
    elementosMobiliarioDanados = elementosMobiliarioDanados.filter((item) => mobiliario.includes(item));
    // Correo para electrónicos si hay elementos
    if (elementosElectronicosFaltantes.length > 0 || elementosElectronicosDanados.length > 0) {
      const detallesElectronicos = [];
      if (elementosElectronicosFaltantes.length > 0) {
        detallesElectronicos.push(`Faltantes: ${elementosElectronicosFaltantes.join(", ")}`);
      }
      if (elementosElectronicosDanados.length > 0) {
        detallesElectronicos.push(`Dañados: ${elementosElectronicosDanados.join(", ")}`);
      }
      await enviaCorreo(
        "soporte@rci-colombia.com",
        "Reporte de equipo electrónico",
        `Se han reportado elementos en el asiento ${asientoReportado}: ${detallesElectronicos.join("; ")}`
      );
    }

    // Correo para mobiliario si hay elementos
    if (elementosMobiliarioFaltantes.length > 0 || elementosMobiliarioDanados.length > 0) {
      const detallesMobiliario = [];
      if (elementosMobiliarioFaltantes.length > 0) {
        detallesMobiliario.push(`Faltantes: ${elementosMobiliarioFaltantes.join(", ")}`);
      }
      if (elementosMobiliarioDanados.length > 0) {
        detallesMobiliario.push(`Dañados: ${elementosMobiliarioDanados.join(", ")}`);
      }
      await enviaCorreo(
        "natalia.echavarria@mobilize-fs.com , nina.mejia@mobilize-fs.com",
        "Reporte de mobiliario",
        `Se han reportado elementos en el asiento ${asientoReportado}: ${detallesMobiliario.join("; ")}`
      );
    }

    // Respuesta exitosa
    res.status(201).json({ message: "Reporte creado exitosamente", data: observacionGuardada });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Error al crear el reporte" });
  }
};


// Cambiar el estado a "Resuelto"
export const resolverObservacion = async (req, res) => {
  const { id, obj } = req.params;

  try {
    // Fetch the observacion first, check for existence
    const observacion = await Observaciones.findById(id).populate("usuarioReportante.id", "correo nombres");

    if (!observacion) {
      return res.status(404).json({ message: "Observación no encontrada" });
    }

    // Filter objects based on the 'obj' parameter and check if any are found
    const resObjetos = observacion.objetos.filter(item => item.objeto === obj);
    if (resObjetos.length === 0) {
      return res.status(404).json({ message: `El objeto ${obj} no fue encontrado en la observación` });
    }

    // Mark the 'estado' field as 'resuelto'
    resObjetos.forEach(item => {
      item.estado = "resuelto";
    });

    // Mark 'objetos' as modified for saving
    observacion.markModified('objetos');

    // Verifying the user reportant data
    if (!observacion.usuarioReportante || observacion.usuarioReportante.length === 0) {
      return res.status(400).json({ message: "No se encontró el usuario reportante." });
    }

    const usuarioReportante = observacion.usuarioReportante[0];
    const correoUsuario = usuarioReportante.id.correo;
    const nombreUsuario = usuarioReportante.nombreReportante;

    if (!correoUsuario || !nombreUsuario) {
      return res.status(400).json({ message: "Faltan datos del usuario reportante." });
    }

    // Sending the email notification
    const mailOptions = {
      from: "rio@rci-colombia.com",
      to: correoUsuario,
      subject: "Observación resuelta",
      text: `Hola, ${nombreUsuario}\n\nTu reporte con el asiento ${observacion.asientoReportado} ha sido resuelto.\nGracias por reportarlo.`,
    };

    await transporter.sendMail(mailOptions);

    // Attempt to save the document with version control handling
    const observacionActualizada = await observacion.save()
      .catch(async (err) => {
        if (err instanceof mongoose.Error.VersionError) {
          // Retry saving the document if there is a version conflict
          const latestObservacion = await Observaciones.findById(id).populate("usuarioReportante.id", "correo nombres");
          if (!latestObservacion) {
            throw new Error('Observación no encontrada al intentar resolver conflicto de versión.');
          }

          const resObjetos = latestObservacion.objetos.filter(item => item.objeto === obj);

          if (resObjetos.length === 0) {
            return res.status(404).json({ message: `El objeto ${obj} no fue encontrado en la observación` });
          }

          // Mark the 'estado' field as 'resuelto'
          resObjetos.forEach(item => {
            item.estado = "resuelto";
          });

          // Mark 'objetos' as modified for saving
          latestObservacion.markModified('objetos');

          // Retry saving the latest document
          return await latestObservacion.save();
        }
        throw err; // Rethrow other errors
      });

    res.status(200).json({
      message: "Estado de la observación actualizado a 'resuelto' y correo enviado al usuario reportante",
      data: observacionActualizada,
    });

  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Error en el servidor", error: error.message });
  }
};


// Mirar todos los reportes
export const getAllReport = async (req, res) => {
  try {
    // Buscar todas las observaciones en la base de datos
    const observaciones = await Observaciones.find();

    // Verificar si hay observaciones en la base de datos
    if (observaciones.length === 0) {
      return res
        .status(404)
        .json({ message: "No se encontraron observaciones." });
    }

    // Enviar la respuesta con todas las observaciones
    res.status(200).json({
      message: "Observaciones obtenidas exitosamente",
      data: observaciones,
    });
  } catch (error) {
    // Manejo de errores
    console.error(error);
    res.status(500).json({ message: "Error al obtener las observaciones" });
  }
};

// Mirar solo los reportes por resolver
export const getObservacionesActivas = async (req, res) => {
  try {
    const observacionesActivas = await Observaciones.find({ "objetos.estado": "activo" });

    // Verificar si hay observaciones activas
    if (!observacionesActivas) {
      return res.status(404).json({ message: "No se encontraron observaciones activas." });
    }

    // Filtrar los objetos dentro de cada observación para excluir aquellos con estado "activo"
    const observacionesFiltradas = observacionesActivas.map(observacion => {
      // Filtrar los objetos de cada observación
      const objetosFiltrados = observacion.objetos.filter(item => item.estado == "activo");

      // Retornar la observación con los objetos filtrados
      return {
        ...observacion.toObject(), // Convertir el documento a un objeto literal
        objetos: objetosFiltrados,  // Reemplazar el array de objetos por el filtrado
      };
    });

    // Enviar la respuesta con las observaciones activas filtradas
    res.status(200).json({
      message: "Observaciones activas obtenidas exitosamente",
      data: observacionesFiltradas,
    });
  } catch (error) {
    // Manejo de errores
    console.error(error);
    res
      .status(500)
      .json({ message: "Error al obtener las observaciones activas" });
  }
};

export const findBySeat = async (req, res) => {
  try {
    const { silla } = req.params; // Obtiene el número de asiento de los parámetros

    const observaciones = await Observaciones.find({
      asientoReportado: silla,
      "objetos.estado": 'activo' // Filtrar solo por estado 'activo'
    }).populate('usuarioReportante'); // Esto para obtener los detalles del usuario que reportó

    const observacionesFiltradas = observaciones.map(observacion => {
      // Filtrar los objetos de cada observación
      const objetosFiltrados = observacion.objetos.filter(item => item.estado == "activo");

      // Retornar la observación con los objetos filtrados
      return {
        ...observacion.toObject(), // Convertir el documento a un objeto literal
        objetos: objetosFiltrados,  // Reemplazar el array de objetos por el filtrado
      };
    });

    if (observaciones.length === 0) {
      return res.status(404).json({ message: "No se encontraron observaciones para el asiento indicado." });
    }

    res.status(200).json(observacionesFiltradas);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Error al buscar las observaciones." });
  }
};

export const getObservacionesPorRango = async (req, res) => {
  const { fechaIni, fechaFinal } = req.params;
  console.log(fechaIni, fechaFinal);

  try {
    if (!fechaIni || !fechaFinal) {
      throw new Error("Las fechas inicial y final son obligatorias.");
    }

    const fechaInicio = new Date(fechaIni);
    const fechaFin = new Date(fechaFinal);

    if (isNaN(fechaInicio.getTime()) || isNaN(fechaFin.getTime())) {
      return res.status(400).json({ error: "Fechas no válidas." });
    }

    const observaciones = await Observaciones.find({
      fecha: { $gte: fechaInicio, $lte: fechaFin },
    });

    res.status(200).json(observaciones);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: error.message });
  }
};