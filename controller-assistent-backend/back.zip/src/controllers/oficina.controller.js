import Oficina from "../models/Oficina.js";
import User from "../models/User.js";
import mongoose from "mongoose";
import Visitante from "../models/Visitante.js";
import moment from 'moment-timezone';
moment.locale("es-us");

// Crear una reserva en la oficina
export const createReserva = async (req, res) => {
  try {
    const { fechaReserva, numeroSilla } = req.body;
    const { usuarioId } = req.params;

    // Obtener la fecha en formato "YYYY-MM-DD" sin la marca de tiempo
    const fechaReservaFormatted = moment(fechaReserva).startOf("day");

    // Consultar el usuario para obtener su documento
    const user = await User.findById(usuarioId);
    const documentoUsuario = user.documento;

    // Verificar si el usuario ya tiene una reserva para la fecha seleccionada
    const existingUserReserva = await User.findOne({
      _id: usuarioId,
      "fechas_reserva.fechaReserva": fechaReservaFormatted,
    });

    // Buscar la oficina existente para la fecha sin la hora
    let existingReserva = await Oficina.findOne({
      fecha: fechaReservaFormatted,
    });

    if (!existingReserva) {
      // Si no existe una reserva para esa fecha, crear una nueva instancia de "Oficina"
      const oficina = new Oficina({
        fecha: fechaReservaFormatted,
        asientosDisponibles: 79,
        reservas: [{ usuario: usuarioId, documento: documentoUsuario, fechaReserva, numeroSilla }], // Incluir el documento del usuario en la reserva
      });

      // Guardar la reserva en el esquema "Oficina"
      existingReserva = await oficina.save();

      // Guardar la reserva en el esquema "User"
      await User.findByIdAndUpdate(usuarioId, {
        $push: { fechas_reserva: { oficina: existingReserva._id, fechaReserva, numeroSilla, documento: documentoUsuario } },
      });

      return res.status(200).json({ message: "Reserva creada exitosamente." });
    } else {
      // Verificar si aún hay asientos disponibles
      if (existingReserva.asientosDisponibles > 0) {
        // Verificar si el usuario ya tiene una reserva en esta fecha
        if (existingReserva.reservas.some((reserva) => reserva.usuario.toString() === usuarioId)) {
          return res.status(400).json({ message: "Ya tienes una reserva para esta fecha." });
        }

        // Verificar si el número de silla ya está reservado para esa fecha
        const numeroSillaExists = existingReserva.reservas.some(
          (reserva) => reserva.numeroSilla === numeroSilla
        );

        if (numeroSillaExists) {
          return res.status(400).json({
            message: "El número de silla ya está reservado para esta fecha.",
          });
        }

        // Agregar la nueva reserva a la matriz existente
        existingReserva.reservas.push({
          usuario: usuarioId,
          fechaReserva,
          numeroSilla,
          documento: documentoUsuario, // Incluir documento en la reserva
        });

        existingReserva.asientosDisponibles -= 1;

        // Guardar la reserva en el esquema "Oficina"
        existingReserva = await existingReserva.save();

        // Guardar la reserva en el esquema "User"
        await User.findByIdAndUpdate(usuarioId, {
          $push: { fechas_reserva: { oficina: existingReserva._id, fechaReserva, numeroSilla, documento: documentoUsuario } }, // Incluir documento en la reserva
        });

        return res.status(200).json({ message: "Reserva creada exitosamente." });
      } else {
        return res.status(400).json({
          message: `La oficina ha alcanzado su límite para el día ${moment(
            fechaReserva
          ).format("DD [de] MMMM [del] YYYY")}.`,
        });
      }
    }
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: "Error al crear la reserva." });
  }
};

export const updateReserva = async (req, res) => {
  try {
  const { fechaReserva, numeroSilla } = req.body;
  const { usuarioId } = req.params;

  const fechaReservaFormatted = moment(fechaReserva).startOf("day").toDate();

  // Buscar usuario
  const user = await User.findById(usuarioId);
  if (!user) {
    return res.status(404).json({ message: "Usuario no encontrado." });
  }

  // Buscar documento Oficina para esa fecha
  const existingReserva = await Oficina.findOne({ fecha: fechaReservaFormatted });
  if (!existingReserva) {
    return res.status(404).json({ message: "No existen reservas para esta fecha." });
  }

  // Buscar índice de la reserva del usuario dentro del array
  const userReservaIndex = existingReserva.reservas.findIndex(
    (reserva) => reserva.usuario.toString() === usuarioId
  );

  if (userReservaIndex === -1) {
    return res.status(400).json({ message: "El usuario no tiene una reserva para esta fecha." });
  }

  // Validar que el número de silla no esté ocupado por otro usuario
  const numeroSillaExists = existingReserva.reservas.some(
    (reserva) =>
      reserva.numeroSilla === numeroSilla &&
      reserva.usuario.toString() !== usuarioId
  );

  if (numeroSillaExists) {
    return res.status(400).json({
      message: "El número de silla ya está reservado para esta fecha.",
    });
  }

  existingReserva.reservas[userReservaIndex].numeroSilla = numeroSilla;
  await existingReserva.save();

  const userData = await User.findById(usuarioId);
  if (userData) {
    const reservaUserIndex = userData.fechas_reserva.findIndex(
      (reserva) =>
        moment(reserva.fechaReserva).isSame(fechaReservaFormatted, "day")
    );

    if (reservaUserIndex !== -1) {
      // Solo modificamos ese campo
      userData.fechas_reserva[reservaUserIndex].numeroSilla = numeroSilla;
      await userData.save();
    }
  }

  return res.status(200).json({ message: "Reserva actualizada exitosamente." });

} catch (err) {
  console.error("Error al actualizar la reserva:", err);
  res.status(500).json({ message: "Error al actualizar la reserva." });
}
}

export const getSillasReservadas = async (req, res) => {
  try {
    const { fecha } = req.params;

    // Obtener la fecha en formato "YYYY-MM-DD" sin la marca de tiempo
    const fechaFormatted = moment(fecha).startOf("day"); // Quitar la hora

    // Buscar las reservas para la fecha especificada
    const oficina = await Oficina.findOne({ fecha: fechaFormatted });

    if (!oficina) {
      return res.status(404).json({ message: "No se encontraron reservas para la fecha especificada." });
    }

    const numerosSillaReservados = oficina.reservas.map((reserva) => reserva.numeroSilla);

    res.json(numerosSillaReservados);
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: "Error al obtener los números de sillas reservadas." });
  }
};

export const getReservas = async (req, res) => {
  try {
    const reservas = await Oficina.find({
      "reservas.usuario": { $ne: null },
    })
      .select("reservas asientosDisponibles")
      .populate({
        path: "reservas.usuario",
        select:
          "nombres apellidos correo enfermedades alergias arl eps direccion numero_acudiente tipo_acudiente acudiente",

      });

    if (!reservas) {
      return res.status(404).json({ message: "No se encontraron reservas." });
    }

    return res.status(200).json({ data: { reservas } });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: "Error al obtener las reservas." });
  }
};
export const getAsistenciasByUsuario = async (req, res) => {
  try {
        const { usuarioId } = req.params;
 
        const reservas = await User.findOne({ _id: usuarioId }).populate(
            "fechas_reserva.oficina",
            "fecha"
          );
       
         
          if (!reservas) {
            return res.status(404).json({
              message: "No se encontraron reservas para el usuario especificado.",
            });
          }
         
         
          const asistenciasFiltradas = reservas.fechas_reserva.filter((reserva) => (reserva.horaLlegada.length > 0 || reserva.horaSalida.length > 0));
          console.log(asistenciasFiltradas);
       
        return res.status(200).json({ reservas: asistenciasFiltradas });
      } catch (error) {
        console.error(error);
        return res
          .status(500)
          .json({ message: "Error al obtener las reservas del usuario." });
      }
};
 
 
export const getReservasByUsuario = async (req, res) => {
  try {
    const { usuarioId } = req.params;
 
    const reservas = await User.findOne({ _id: usuarioId }).populate(
      "fechas_reserva.oficina",
      "fecha"
    );
 
    if (!reservas) {
      return res.status(404).json({
        message: "No se encontraron reservas para el usuario especificado.",
      });
    }
 
    const reservasFiltradas = reservas.fechas_reserva.filter((reserva) => reserva.horaLlegada.length == 0 && reserva.horaSalida.length == 0 && reserva.numeroSilla);
    console.log(reservasFiltradas)
   
    return res.status(200).json({ reservas: reservasFiltradas });
  } catch (error) {
    console.error(error);
    return res
      .status(500)
      .json({ message: "Error al obtener las reservas del usuario." });
  }
};

export const getReservasByFecha = async (req, res) => {
  try {
    const { fecha } = req.params;

    // Obtener el inicio y fin del día especificado utilizando moment
    const startOfDay = moment(fecha).startOf("day");
    const endOfDay = moment(fecha).endOf("day");

    const reservas = await Oficina.find({
      fecha: {
        $gte: startOfDay.toDate(), // Fecha y hora de inicio del día
        $lte: endOfDay.toDate(), // Fecha y hora de fin del día
      },
    })
      .select("reservas reservasReemplazo asientosDisponibles")
      .populate([
        {
          path: "reservas.usuario",
          select:
            "tipo_documento documento nombres apellidos telefono correo enfermedades alergias brigadista arl eps direccion numero_acudiente tipo_acudiente acudiente",
        },
        {
          path: "reservasReemplazo.reemplazo",
          select:
            "tipo_documento documento nombres apellidos telefono correo enfermedades alergias brigadista arl eps direccion numero_acudiente tipo_acudiente acudiente",
        },
      ]);

    if (!reservas) {
      return res.status(404).json({ message: "No se encontraron reservas." });
    }

    // Aplicar la regla para mostrar los datos del reemplazo si están disponibles
    reservas.forEach(oficina => {
      oficina.reservasReemplazo.forEach(reservaReemplazo => {
        const index = oficina.reservas.findIndex(reserva => reserva.usuario._id.toString() === reservaReemplazo.usuario.toString());
        if (index !== -1) {
          oficina.reservas[index].usuario = reservaReemplazo.reemplazo;
        } else {
          // Si no hay reserva para este usuario, agregamos el reemplazo directamente a las reservas
          oficina.reservas.push({
            usuario: reservaReemplazo.reemplazo,
            fechaReserva: reservaReemplazo.fechaReserva,
          });
        }
      });
    });

    // Procesar las reservas para incluir horaLlegada y horaSalida
    reservas.forEach(oficina => {
      oficina.reservas.forEach(reserva => {
        // Asegúrate de que horaLlegada y horaSalida sean siempre un array
        reserva.horaLlegada = reserva.horaLlegada || []; // Si no hay, asigna un array vacío
        reserva.horaSalida = reserva.horaSalida || []; // Si no hay, asigna un array vacío

        // Asignar la primera hora de llegada y la última hora de salida
        reserva.horaLlegada = reserva.horaLlegada.length > 0 ? [reserva.horaLlegada[0]] : []; // Dejarlo como un array
        reserva.horaSalida = reserva.horaSalida.length > 0 ? [reserva.horaSalida[reserva.horaSalida.length - 1]] : []; // Dejarlo como un array
      });
    });


    const asientosDisponibles = await Oficina.findOne({
      fecha: startOfDay.toDate(),
    }).select("asientosDisponibles");

    if (!asientosDisponibles) {
      return res.status(404).json({
        message: `No se encontró reservaciones para ${startOfDay.format("DD [de] MMMM [del] YYYY")}.`,
      });
    }

    return res.status(200).json({ data: { reservas, asientosDisponibles } });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: "Error al obtener las reservas." });
  }
};



export const importReserva = async (req, res) => {
  try {
    const eventos = req.body.EventCollection.rows;

    let eventosEntradaProcesados = 0;
    let eventosSalidaProcesados = 0;

    for (const evento of eventos) {
      const { user_id, server_datetime, device_id } = evento;
      const userId = user_id.user_id;

      // Buscar el usuario en el esquema User usando el documento
      let user = await User.findOne({ documento: userId });
      if (!user) {
        console.log(`Usuario con documento ${userId} no encontrado`);
        continue;
      } else {
        console.log(`Usuario con documento ${userId} encontrado`);
      }

      // Ajustar la fecha y hora para Colombia
      const fechaEvento = new Date(new Date(evento.server_datetime).setHours(0, 0, 0, 0));

      // Hora UTC
      const horaEvento = moment(server_datetime).tz('UTC').format('HH:mm:ss');

      let reservaActualizada = false;

      for (let reserva of user.fechas_reserva) {
        const fechaReserva = new Date(reserva.fechaReserva); // Convertir a Date
        fechaReserva.setHours(0, 0, 0, 0); // Establecer a medianoche

        if (fechaReserva.getTime() === fechaEvento.getTime()) {
          if (device_id.name === "Entrada") {
            if (!reserva.horaLlegada.includes(horaEvento)) {
              reserva.horaLlegada.push(horaEvento);
              eventosEntradaProcesados++;
            }
          } else if (device_id.name === "Salida") {
            if (!reserva.horaSalida.includes(horaEvento)) {
              reserva.horaSalida.push(horaEvento);
              eventosSalidaProcesados++;
            }
          }
          reservaActualizada = true;
          break;
        }
      }

      // Si no se encontró reserva, crear una nueva
      if (!reservaActualizada) {
        console.log(`Creando reserva para el usuario ${userId}`);
        const nuevaReserva = {
          fechaReserva: fechaEvento,
          horaLlegada: [],
          horaSalida: [],
        };
        if (device_id.name === "Entrada") {
          nuevaReserva.horaLlegada.push(horaEvento);
          eventosEntradaProcesados++;
        } else if (device_id.name === "Salida") {
          nuevaReserva.horaSalida.push(horaEvento);
          eventosSalidaProcesados++;
        }
        user.fechas_reserva.push(nuevaReserva);
      }

      // Guardar los cambios en el usuario
      user = await user.save();

      // Actualizar el esquema Oficina
      let existingOficina = await Oficina.findOne({ fecha: fechaEvento });

      if (!existingOficina) {
        // Crear una nueva oficina si no existe para esta fecha
        existingOficina = new Oficina({
          fecha: fechaEvento,
          asientosDisponibles: 80,
          reservas: [],
        });
      }

      // Actualizar la reserva en la oficina
      const reservaOficina = existingOficina.reservas.find(
        (reserva) =>
          reserva.usuario.toString() === user._id.toString() &&
          moment(reserva.fechaReserva).isSame(fechaEvento, "day")
      );

      if (reservaOficina) {
        if (device_id.name === "Entrada") {
          if (!reservaOficina.horaLlegada.includes(horaEvento)) {
            reservaOficina.horaLlegada.push(horaEvento);
            console.log("Hora de llegada: ", reservaOficina.horaLlegada);
          }
        } else if (device_id.name === "Salida") {
          if (!reservaOficina.horaSalida.includes(horaEvento)) {
            reservaOficina.horaSalida.push(horaEvento);
          }
        }
      } else {
        existingOficina.reservas.push({
          usuario: user._id,
          fechaReserva: fechaEvento,
          horaLlegada: device_id.name === "Entrada" ? [horaEvento] : [],
          horaSalida: device_id.name === "Salida" ? [horaEvento] : [],
        });
        console.log("Hora de llegada: ", reservaOficina?.horaLlegada);
      }

      // Guardar los cambios en el esquema Oficina
      await existingOficina.save();
    }

    console.log(`Eventos de entrada procesados: ${eventosEntradaProcesados}`);
    console.log(`Eventos de salida procesados: ${eventosSalidaProcesados}`);

    res.status(200).json({ message: "Eventos procesados exitosamente" });
  } catch (error) {
    console.error("Error al procesar eventos:", error);
    res.status(500).json({ message: "Error al procesar eventos" });
  }
};

export const getReservasPorRangoDeFechas = async (req, res) => {
  const { fechaInicial, fechaFinal } = req.query;

  try {
    // Convertir las fechas en objetos Date
    const fechaInicio = new Date(fechaInicial);
    const fechaFin = new Date(fechaFinal);

    // Establecer la fecha final al último milisegundo del día
    fechaFin.setUTCHours(23, 59, 59, 999);



    // Obtener las reservas dentro del rango de fechas
    const oficinas = await Oficina.find({
      fecha: { $gte: fechaInicio, $lte: fechaFin },
    }).populate({
      path: "reservas.usuario",
      model: User,
      select: "nombres apellidos documento fechaReserva horaLlegada horaSalida", // Seleccionar solo los campos deseados del usuario
    });

    // Mapear los resultados para obtener solo la información necesaria
    const reservasConInfoUsuario = oficinas.flatMap((oficina) =>
      oficina.reservas.map((reserva) => ({
        _id: oficina._id,
        fecha: oficina.fecha,
        asientosDisponibles: oficina.asientosDisponibles,
        usuario: reserva.usuario,
        fechaReserva: reserva.fechaReserva,
        horaSalida: reserva.horaSalida,
        horaLlegada: reserva.horaLlegada,
        asiento: reserva.numeroSilla
      }))
    );

    res.json(reservasConInfoUsuario);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error al obtener las reservas." });
  }
};
export const getReservasPorPuestos = async (req, res) => {
    const { fechaInicial, fechaFinal, numeroSilla } = req.query;
    
    try {
        // Validar que vengan todos los parámetros
        if (!fechaInicial || !fechaFinal || !numeroSilla) {
            return res.status(400).json({ 
                error: "Se requieren fechaInicial, fechaFinal y numeroSilla como parámetros en la URL" 
            });
        }

        // Convertir fechas y validar
        const fechaInicio = new Date(fechaInicial);
        let fechaFin = new Date(fechaFinal);
        
        // Verificar si las fechas son válidas
        if (isNaN(fechaInicio.getTime())) {
            return res.status(400).json({ error: "fechaInicial no es una fecha válida" });
        }
        if (isNaN(fechaFin.getTime())) {
            return res.status(400).json({ error: "fechaFinal no es una fecha válida" });
        }

        // Ajustar la fecha final para incluir todo el día
        fechaFin = new Date(fechaFin);
        fechaFin.setUTCHours(23, 59, 59, 999);
        
        const oficinas = await Oficina.find({
            fecha: { 
                $gte: fechaInicio, 
                $lte: fechaFin 
            },
            "reservas.numeroSilla": Number(numeroSilla)
        })
        .populate({
            path: "reservas.usuario",
            model: "User",
            select: "nombres apellidos"
        });

        const resultados = oficinas.flatMap(oficina => 
            oficina.reservas
                .filter(reserva => reserva.numeroSilla === Number(numeroSilla))
                .map(reserva => ({
                    fechaReserva: reserva.fechaReserva,
                    horaLlegada: reserva.horaLlegada,
                    horaSalida: reserva.horaSalida,
                    nombres: reserva.usuario?.nombres,
                    apellido: reserva.usuario?.apellidos
                }))
        );
        
        res.json(resultados);
    } catch (error) {
        console.error("Error detallado:", error);
        res.status(500).json({ 
            error: "Error al obtener las reservas.",
            details: error.message 
        });
    }
}

// Eliminar una reserva de la oficina

export const deleteReserva = async (req, res) => {
  try {
    const { userId, fechaReserva } = req.params;

    if (
      !mongoose.Types.ObjectId.isValid(userId) ||
      !moment(fechaReserva, "YYYY-MM-DD", true).isValid()
    ) {
      return res
        .status(400)
        .json({ message: "Datos de usuario o fecha de reserva inválidos." });
    }

    // Convertir la fecha a un formato compatible sin hora, minuto y segundo
    const formattedFechaReserva = moment(fechaReserva)
      .startOf("day")
      .toISOString();

    // Buscar la reserva en la colección "Oficina"
    const office = await Oficina.findOne({
      "reservas.usuario": userId,
      "reservas.fechaReserva": {
        $gte: formattedFechaReserva,
        $lt: moment(formattedFechaReserva).add(1, "days").toISOString(),
      },
    });

    // Si la reserva no existe en "Oficina", retorna un error
    if (!office) {
      return res
        .status(404)
        .json({ message: "Reserva no encontrada en ninguna colección." });
    }

    // Filtrar y eliminar la reserva de la colección "Oficina"
    office.reservas = office.reservas.filter(
      (reserva) =>
        !(
          reserva.usuario.toString() === userId &&
          moment(reserva.fechaReserva).startOf("day").toISOString() ===
          formattedFechaReserva
        )
    );

    // Incrementar el número de asientos disponibles en 1
    office.asientosDisponibles += 1;

    // Guardar los cambios en la colección "Oficina"
    await office.save();

    // Buscar la reserva en la colección "User"
    const user = await User.findOne({
      _id: userId,
      "fechas_reserva.fechaReserva": {
        $gte: formattedFechaReserva,
        $lt: moment(formattedFechaReserva).add(1, "days").toISOString(),
      },
    });

    // Si la reserva existe en "User", filtrar y eliminar la reserva de la colección "User"
    if (user) {
      user.fechas_reserva = user.fechas_reserva.filter((reserva) => {
        if (
          reserva.oficina &&
          reserva.oficina.toString() === office._id.toString()
        ) {
          return (
            moment(reserva.fechaReserva).startOf("day").toISOString() !==
            formattedFechaReserva
          );
        }
        return true;
      });

      // Guardar los cambios en la colección "User"
      await user.save();
    }

    return res.status(200).json({ message: "Reserva eliminada exitosamente." });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: "Error al eliminar la reserva." });
  }
};

// reservas por rango en visitantes

export const getReservasVisitantePorRangoDeFechas = async (req, res) => {
  const { fechaInicial, fechaFinal } = req.query;

  try {
    // Convertir las fechas en objetos Date
    const fechaInicio = new Date(fechaInicial);
    const fechaFin = new Date(fechaFinal);

    // Obtener las reservas de visitantes dentro del rango de fechas
    const oficinas = await Oficina.find({
      fecha: { $gte: fechaInicio, $lte: fechaFin },
    }).populate({
      path: "reservasVisitante.usuario",
      model: Visitante,
      select:
        "tipo_documento documento nombres apellidos sangre telefono direccion eps arl enfermedades alergias fechas_reserva",
    });

    // Mapear los resultados para obtener solo la información necesaria
    const reservasConInfoVisitante = oficinas.flatMap((oficina) =>
      oficina.reservasVisitante.map((reservaVisitante) => ({
        _id: oficina._id,
        fecha: oficina.fecha,
        asientosDisponibles: oficina.asientosDisponibles,
        visitante: reservaVisitante.usuario,
        fechaReserva: reservaVisitante.fechaReserva,
        responsable_mobilize:
          reservaVisitante.usuario.fechas_reserva[0].responsable_mobilize,
        motivo: reservaVisitante.usuario.fechas_reserva[0].motivo,
        acudiente: reservaVisitante.usuario.fechas_reserva[0].acudiente,
        tipo_acudiente:
          reservaVisitante.usuario.fechas_reserva[0].tipo_acudiente,
        numero_acudiente:
          reservaVisitante.usuario.fechas_reserva[0].numero_acudiente,
      }))
    );

    res.json(reservasConInfoVisitante);
  } catch (error) {
    console.error(error);
    res
      .status(500)
      .json({ error: "Error al obtener las reservas de visitantes." });
  }
};

//Reserva por fecha FILTRO


export const getReservasVisitanteByFecha = async (req, res) => {
  try {
    const { fecha } = req.params;

    // Formatea la fecha de entrada al principio y final del día
    const fechaInicio = moment(fecha).startOf("day").toDate();
    const fechaFin = moment(fecha).endOf("day").toDate();

    const reservas = await Visitante.aggregate([
      {
        $match: {
          "fechas_reserva.fechaReserva": {
            $gte: fechaInicio,
            $lte: fechaFin,
          },
        },
      },
      {
        $project: {
          tipo_documento: 1,
          documento: 1,
          nombres: 1,
          apellidos: 1,
          sangre: 1,
          telefono: 1,
          direccion: 1,
          eps: 1,
          arl: 1,
          enfermedades: 1,
          alergias: 1,
          fechas_reserva: {
            $filter: {
              input: "$fechas_reserva",
              as: "fechaReserva",
              cond: {
                $and: [
                  { $gte: ["$$fechaReserva.fechaReserva", fechaInicio] },
                  { $lte: ["$$fechaReserva.fechaReserva", fechaFin] },
                ],
              },
            },
          },
        },
      },
    ]);

    if (!reservas || reservas.length === 0) {
      return res.status(404).json({
        message: `No se encontró reservaciones para ${moment(fecha).format(
          "DD [de] MMMM [del] YYYY"
        )}.`,
      });
    }

    return res.status(200).json({ data: { reservas } });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: "Error al obtener las reservas." });
  }
};

// importacion masiva

// Función para procesar y filtrar los datos del CSV y asignar fechas de reserva, hora de entrada y hora de salida
function filterData(jsonData) {
  // Filtrar y procesar los datos en formato JSON
  const userDataMap = new Map();

  for (const data of jsonData) {
    const evento = data.Evento;
    const usuarios = data.Usuarios;
    const fecha = moment(data.Fecha).format("YYYY-MM-DD");

    // Filtrar por tipo de evento y usuarios específicos
    if (
      evento === "1:1 authentication succeeded (Card)" ||
      evento === "1:N authentication succeeded (Fingerprint)" ||
      evento === "1:N authentication succeeded (Face)"
    ) {
      const match = usuarios.match(/\((.*?)\)/);
      const nombreUsuario = match ? match[1] : "";
      const documentoUsuario = usuarios.split("(")[0].trim();

      if (!userDataMap.has(fecha)) {
        userDataMap.set(fecha, new Map());
      }

      const userMap = userDataMap.get(fecha);

      if (!userMap.has(documentoUsuario)) {
        userMap.set(documentoUsuario, {
          fechaReserva: fecha,
          horaLlegada: [],
          horaSalida: [],
        });
      }

      const user = userMap.get(documentoUsuario);
      const hora = moment(data.Fecha).format("HH:mm:ss");

      if (data.Dispositivos === "Entrada") {
        user.horaLlegada.push(hora);
      } else if (data.Dispositivos === "Salida") {
        user.horaSalida.push(hora);
      }
    }
  }

  const result = [];

  for (const [fecha, userMap] of userDataMap.entries()) {
    for (const [documentoUsuario, user] of userMap.entries()) {
      result.push({
        documento: documentoUsuario,
        fechaReserva: fecha,
        horaLlegada: user.horaLlegada,
        horaSalida: user.horaSalida,
      });
    }
  }

  return result;
}

export const reservaMasiva = async (req, res) => {
  try {
    const jsonData = req.body.jsonData;

    if (!jsonData) {
      return res.status(400).json({ error: "JSON data is required." });
    }

    // Filtrar los datos del JSON
    const userData = filterData(jsonData);

    // Iterar a través de los datos filtrados
    for (const userDatum of userData) {
      const { documento, fechaReserva, horaLlegada, horaSalida } = userDatum;

      // Formatear la fecha de reserva para comparación
      const fechaReservaFormatted = moment(fechaReserva)
        .startOf("day")
        .toDate();

      // Buscar al usuario en la base de datos por su documento
      let user = await User.findOne({ documento: documento });

      if (!user) {
        continue; // Pasar al siguiente usuario si no se encuentra
      }

      // Eliminar las reservas existentes con la misma fecha
      user.fechas_reserva = user.fechas_reserva.filter(
        (reserva) =>
          !moment(reserva.fechaReserva).isSame(fechaReservaFormatted, "day")
      );

      // Guardar cambios en el usuario
      user = await user.save();

      // Buscar la oficina existente para la fecha de reserva
      let existingOficina = await Oficina.findOne({
        fecha: fechaReservaFormatted,
      });

      if (!existingOficina) {
        // Crear nueva oficina si no existe para esta fecha
        existingOficina = new Oficina({
          fecha: fechaReservaFormatted,
          asientosDisponibles: 80,
          reservas: [],
        });
      }

      // Eliminar las reservas existentes con la misma fecha y usuario en la oficina
      existingOficina.reservas = existingOficina.reservas.filter(
        (reserva) =>
          !(
            reserva.usuario.toString() === user._id.toString() &&
            moment(reserva.fechaReserva).isSame(fechaReservaFormatted, "day")
          )
      );

      // Guardar cambios en la oficina
      await existingOficina.save();

      // Agregar nueva reserva en el usuario
      user.fechas_reserva.push({
        fechaReserva: fechaReservaFormatted,
        horaLlegada: horaLlegada,
        horaSalida: horaSalida,
      });

      // Guardar cambios en el usuario nuevamente
      user = await user.save();

      // Buscar nuevamente la oficina después de guardar la reserva en el usuario
      existingOficina = await Oficina.findOne({ fecha: fechaReservaFormatted });

      if (!existingOficina) {
        existingOficina = new Oficina({
          fecha: fechaReservaFormatted,
          asientosDisponibles: 80,
          reservas: [],
        });
      }

      // Agregar nueva reserva en la oficina
      existingOficina.reservas.push({
        usuario: user._id,
        fechaReserva: fechaReservaFormatted,
        horaLlegada: horaLlegada,
        horaSalida: horaSalida,
      });

      existingOficina.asientosDisponibles =
        80 - existingOficina.reservas.length;

      // Guardar cambios en la oficina
      await existingOficina.save();
    }

    return res
      .status(200)
      .json({ message: "La reserva y la hora fue asignada correctamente." });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: "Error processing JSON data." });
  }
};

export const getAsientosPeriodoFechas = async (req,res) =>{
  try{

  }catch{

  }finally{


  }
}