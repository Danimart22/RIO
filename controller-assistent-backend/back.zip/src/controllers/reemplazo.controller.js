import Reemplazo from "../models/Reemplazo.js";
import Oficina from '../models/Oficina.js';
import User from "../models/User.js";
import moment from 'moment';


export const createReemplazo = async (req, res) => {
  try {
    const {
      tipo_documento,
      documento,
      nombres,
      apellidos,
      sangre,
      telefono,
      cargo,
      acudiente,
      tipo_acudiente,
      numero_acudiente,
      direccion,
      eps,
      arl,
      enfermedades,
      alergias,
      estado,
      fechas_de_reemplazo, // Array de objetos { desde, hasta, usuarios: [] }
    } = req.body;

    // Verificar si ya existe un reemplazo con el mismo documento
    const existingReemplazo = await Reemplazo.findOne({ documento });
    if (existingReemplazo) {
      return res.status(400).json({ message: "Ya existe un reemplazo con este documento." });
    }

    // Crear un nuevo reemplazo
    const newReemplazo = new Reemplazo({
      tipo_documento,
      documento,
      nombres,
      apellidos,
      sangre,
      telefono,
      cargo,
      acudiente,
      tipo_acudiente,
      numero_acudiente,
      direccion,
      eps,
      arl,
      enfermedades,
      alergias,
      estado,
      fechas_de_reemplazo,
    });
    
    // Guardar el reemplazo en la base de datos
    const savedReemplazo = await newReemplazo.save();
    
    // Asignar usuarios al reemplazo
    if (fechas_de_reemplazo && fechas_de_reemplazo.length > 0) {
      for (const fecha of fechas_de_reemplazo) {
        for (const userId of fecha.usuarios) {
          await User.findByIdAndUpdate(userId, {
            $set: {
              reemplazo: {
                reemplazoId: savedReemplazo._id,
                nombre: `${nombres} ${apellidos}`,
                rangoFechas: { desde: fecha.desde, hasta: fecha.hasta },
              },
            },
          });
        }
      }
    }
    
    return res.status(201).json({ message: "Reemplazo creado exitosamente.", reemplazo: savedReemplazo });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: "Error al crear el reemplazo." });
  }
};


export const getReemplazo = async (req, res) =>{
  try {
    const reemplazos = await Reemplazo.find().select(
      'tipo_documento documento nombres apellidos sangre telefono cargo acudiente tipo_acudiente numero_acudiente direccion eps arl enfermedades alergias'
    )
    res.status(200).json(reemplazos);
  } catch (error) {
    console.error("Error obteniendo los reemplazos:", error);
    res.status(500).json({ message: "Error obteniendo los reemplazos" });
  }
}

export const deleteReemplazo = async (req, res) => {
  const { reemplazoId } = req.params; // Obtén el ID del reemplazo de los parámetros de la solicitud
  
  try {
      // Busca y elimina el reemplazo por su ID
      const deletedReemplazo = await Reemplazo.findByIdAndDelete(reemplazoId);
      
      if (!deletedReemplazo) {
          // Si no se encuentra el reemplazo, responde con un estado 404 (No encontrado)
          return res.status(404).json({ message: "Reemplazo no encontrado" });
      }
      
      // Si se elimina correctamente, responde con un estado 200 (Éxito)
      res.status(200).json({ message: "Reemplazo eliminado correctamente" });
  } catch (error) {
      // Si hay un error, responde con un estado 500 (Error del servidor) y un mensaje de error
      console.error("Error al eliminar el reemplazo:", error);
      res.status(500).json({ message: "Error al eliminar el reemplazo" });
  }
};


export const asignarReemplazo = async (req, res) => {
  try {
    const { usuarioId, reemplazoId, desde, hasta } = req.body;

    console.log("Datos enviados a la API:", { usuarioId, reemplazoId, desde, hasta });

    // Verificar si el usuario ya tiene un reemplazo en las fechas especificadas
    const existingReemplazo = await User.findOne({
      _id: usuarioId,
      'reemplazos.rangoFechas.desde': { $lte: hasta },
      'reemplazos.rangoFechas.hasta': { $gte: desde }
    });

    if (existingReemplazo) {
      return res.status(400).json({ message: 'El usuario ya tiene un reemplazo asignado para estas fechas.' });
    }

    // Crear la referencia del reemplazo en el usuario
    await User.findByIdAndUpdate(usuarioId, {
      $push: {
        reemplazos: {
          reemplazoId,
          nombre: reemplazoId.nombre,
          rangoFechas: { desde, hasta }
        }
      }
    });

    // Crear la referencia del reemplazo en el modelo Reemplazo
    await Reemplazo.findByIdAndUpdate(reemplazoId, {
      $push: {
        fechas_de_reemplazo: { usuarioId, desde, hasta }
      }
    });

    // Crear la reserva en la oficina correspondiente para cada fecha dentro del rango
    const fechaInicio = moment(desde);
    const fechaFin = moment(hasta);
    const fechas = [];
    while (fechaInicio.isSameOrBefore(fechaFin, 'day')) {
      fechas.push(fechaInicio.clone().toDate());
      fechaInicio.add(1, 'day');
    }

    await Promise.all(fechas.map(async (fecha) => {
      const existingOficina = await Oficina.findOne({ fecha });
      if (!existingOficina) {
        // Si no hay una oficina para la fecha especificada, crea una nueva
        await Oficina.create({ fecha });
      }
      
      // Añadir la reserva de reemplazo a la oficina
      await Oficina.updateOne(
        { fecha },
        {
          $push: {
            reservasReemplazo: {
              usuario: usuarioId,
              reemplazo: reemplazoId,
              fechaReserva: fecha
            }
          }
        }
        );
      }));
      
      return res.status(200).json({ message: 'Reemplazo asignado exitosamente.' });
    } catch (error) {
      console.error(error);
    return res.status(500).json({ message: 'Error al asignar el reemplazo.' });
  }
};


export const getReemplazoByFecha = async (req, res) => {
  try {
    const { userId, fecha } = req.params;
    
    // Buscar el usuario por su ID
    const usuario = await User.findById(userId);
    if (!usuario) {
      return res.status(404).json({ message: 'Usuario no encontrado.' });
    }
    
    // Convertir la fecha a un objeto Date
    const fechaBusqueda = new Date(fecha);
    
    // Buscar el reemplazo para el usuario en la fecha específica
    const reemplazo = usuario.reemplazos.find(reemplazo => {
      return (
        reemplazo.rangoFechas.desde <= fechaBusqueda &&
        reemplazo.rangoFechas.hasta >= fechaBusqueda
        );
      });
      
      // Si no se encuentra el reemplazo para la fecha especificada, devolver un mensaje
      if (!reemplazo) {
        return res.status(404).json({ message: 'No se encontró ningún reemplazo para el usuario en la fecha especificada.' });
      }
      
      // Si se encuentra el reemplazo, buscar sus detalles en el modelo Reemplazo
      const detallesReemplazo = await Reemplazo.findById(reemplazo.reemplazoId);
      if (!detallesReemplazo) {
      return res.status(404).json({ message: 'Detalles del reemplazo no encontrados.' });
    }

    // Devolver los detalles del reemplazo
    return res.status(200).json(detallesReemplazo);
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: 'Error al obtener los datos del reemplazo.' });
  }
}

export const eliminarAsignacionReemplazo = async (req, res) => {
  try {
    const { userId, reemplazoId } = req.params;

    // Eliminar el reemplazo del usuario
    await User.findByIdAndUpdate(userId, {
      $pull: {
        reemplazos: { _id: reemplazoId }
      }
    });

    // Eliminar el reemplazo del modelo Reemplazo
    await Reemplazo.findByIdAndDelete(reemplazoId);

    return res.status(200).json({ message: 'Reemplazo eliminado exitosamente.' });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: 'Error al eliminar el reemplazo.' });
  }
};
