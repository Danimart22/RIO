import User from "../models/User.js";
import Roles from "../models/Roles.js";
import bcrypt from "bcryptjs";
import nodemailer from "nodemailer";
import {SES_KEY, SES_SECRETEKEY} from "../config.js"

const transporter = nodemailer.createTransport({
  host: "email-smtp.us-east-1.amazonaws.com",
  port: 465,
  secure: true,
  auth: {
    user: SES_KEY,
    pass: SES_SECRETEKEY,
  },
})
// Petición para crear un usuario
export const createUser = async (req, res) => {
  try {
    const {
      username,
      documento,
      tipo_documento,
      nombres,
      apellidos,
      correo,
      area,
      cargo,
      sangre,
      telefono,
      acudiente,
      tipo_acudiente,
      numero_acudiente,
      direccion,
      eps,
      arl,
      password,
      enfermedades,
      alergias,
      estado,
      fechas_asistencias,
      roles,
    } = req.body;

    // Verificar si ya existe un usuario con el mismo documento o correo
    const existingUser = await User.findOne({
      $or: [{ documento }, { correo }],
    });

    if (existingUser) {
      // Si el usuario existe y su estado es "inactivo", cambiar a "activo"
      if (existingUser.estado === "inactivo") {
        existingUser.estado = "activo";
        await existingUser.save();

        return res.status(200).json({
          _id: existingUser._id,
          username: existingUser.username,
          correo: existingUser.correo,
          nombres: existingUser.nombres,
          apellidos: existingUser.apellidos,
          roles: existingUser.roles,
          message: "Usuario reactivado exitosamente.",
        });
      }

      return res.status(400).json({
        message: "Ya existe otro usuario con el mismo documento o correo.",
      });
    }

    const rolesFound = await Roles.find({ nombre: { $in: roles } });

    const user = new User({
      username,
      documento,
      tipo_documento,
      nombres,
      apellidos,
      correo,
      area,
      cargo,
      sangre,
      telefono,
      acudiente,
      tipo_acudiente,
      numero_acudiente,
      direccion,
      eps,
      arl,
      password,
      enfermedades,
      alergias,
      estado,
      fechas_asistencias,
      roles: rolesFound.map((role) => role._id),
    });

    user.password = await User.encryptPassword(user.password);

    const savedUser = await user.save();
    io.emit('newUser', savedUser);

    return res.status(200).json({
      _id: savedUser._id,
      username: savedUser.username,
      correo: savedUser.correo,
      nombres: savedUser.nombres,
      apellidos: savedUser.apellidos,
      roles: savedUser.roles,
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: "Error al crear el usuario." });
  }
};

// Obtener los usuarios activos
export const getUsers = async (req, res) => {
  try {
    const users = await User.find({ estado: "activo" });
    return res.json(users);
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: "Error al obtener los usuarios." });
  }
};

export const getUsersEmpleados = async (req, res) => {
  try {
    const users = await User.find({
      estado: "activo",
      roles: { $in: ["empleado"] }, // Agregar consulta para el rol "empleado"
    });
    return res.json(users);
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: "Error al obtener los usuarios." });
  }
};

// Obtener todos los usuarios
export const getAllUsers = async (req, res) => {
  try {
    const users = await User.find().populate({
      path: "roles",
      select: "nombre", // Indicamos que solo queremos mostrar el campo 'nombre' del modelo 'Roles'
    });

    return res.json(users);
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: "Error al obtener los usuarios." });
  }
};

// Obtener un usuario por su ID
export const getUserById = async (req, res) => {
  try {
    const user = await User.findOne({
      _id: req.params.userId,
    }).populate('roles', 'nombre');

    if (!user) {
      return res.status(404).json({ message: "Usuario no encontrado." });
    }
    return res.json(user);
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: "Error al obtener el usuario." });
  }
};

// Actualizar un usuario
export const updateUser = async (req, res) => {
  try {
    const userId = req.params.userId;
    const {
      username,
      tipo_documento,
      documento,
      nombres,
      apellidos,
      correo,
      sangre,
      telefono,
      acudiente,
      tipo_acudiente,
      numero_acudiente,
      direccion,
      eps,
      cargo,
      empresa,
      area,
      arl,
      password,
      enfermedades,
      alergias,
      estado,
      asiento,
      fechas_asistencias,
      brigadista,
      roles, // Cambio aquí: Ahora roles contendrá nombres de roles en lugar de _id
    } = req.body;

    // Transformar los nombres de los roles en IDs
    const existingUser = await User.findById(userId);

    // Verificar si se proporcionaron roles en el formulario, de lo contrario mantener los roles existentes
    const roleIds = roles && Array.isArray(roles)
      ? await Promise.all(roles.map(async roleName => {
          const role = await Roles.findOne({ nombre: roleName });
          return role ? role._id : null;
        }))
      : existingUser.roles;

    // Verificar si el documento se está actualizando y ya existe en otro usuario
    if (documento) {
      const existingUserDocumento = await User.findOne({
        documento,
        _id: { $ne: userId },
      });
      if (existingUserDocumento) {
        return res
          .status(400)
          .json({ message: "Ya existe otro usuario con el mismo documento." });
      }
    }

    // Verificar si el correo se está actualizando y ya existe en otro usuario
    if (correo) {
      const existingUserCorreo = await User.findOne({
        correo,
        _id: { $ne: userId },
      });
      if (existingUserCorreo) {
        return res
          .status(400)
          .json({ message: "Ya existe otro usuario con el mismo correo." });
      }
    }

    // Encriptar la contraseña si se proporciona una nueva
    if (password) {
      const encryptedPassword = await User.encryptPassword(password);
      req.body.password = encryptedPassword;
    }

    const updatedUser = await User.findByIdAndUpdate(
      userId,
      {
        // Utiliza directamente los campos del formulario
        username,
        tipo_documento,
        documento,
        nombres,
        apellidos,
        correo,
        sangre,
        cargo,
        empresa,
        area,
        telefono,
        acudiente,
        tipo_acudiente,
        numero_acudiente,
        direccion,
        eps,
        arl,
        password,
        enfermedades,
        alergias,
        estado,
        asiento,
        fechas_asistencias,
        brigadista,
        roles: roleIds, // Cambio aquí: Actualizar roles con los IDs
      },
      { new: true }
    );

    if (!updatedUser) {
      return res.status(404).json({ message: "Usuario no encontrado." });
    }

    const messageSuccess = `El empleado ${updatedUser.nombres} ${updatedUser.apellidos} se ha actualizado correctamente.`;

    // ... (código para emitir la actualización a través de socket, si es necesario) ...

    return res.status(200).json({
      _id: updatedUser._id,
      username: updatedUser.username,
      correo: updatedUser.correo,
      nombres: updatedUser.nombres,
      apellidos: updatedUser.apellidos,
      roles: updatedUser.roles,
      message: messageSuccess,
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: "Error al actualizar el usuario." });
  }
};


export const updatePassword = async (req, res) => {
  try {
    const { id } = req.params;
    const { currentPassword, newPassword } = req.body;

    // Buscar al usuario por su ID en la base de datos
    const user = await User.findById(id);

    if (!user) {
      return res.status(404).json({ message: "Usuario no encontrado" });
    }

    // Validar que la contraseña actual ingresada sea correcta
    const isPasswordValid = await bcrypt.compare(
      currentPassword,
      user.password
    );

    if (!isPasswordValid) {
      return res
        .status(400)
        .json({ message: "La contraseña actual que ingresaste es incorrecta" });
    }

    // Encriptar la nueva contraseña
    const salt = await bcrypt.genSalt(10);
    const hashedNewPassword = await bcrypt.hash(newPassword, salt);

    // Actualizar la contraseña en la base de datos
    user.password = hashedNewPassword;
    await user.save();

    res
      .status(200)
      .json({ message: "La contraseña actualizada correctamente" });
  } catch (error) {
    console.error("Error al cambiar la contraseña:", error);
    res.status(500).json({ message: "Error al cambiar la contraseña" });
  }
};

export const forgetPassword = async (req, res) => {
  try {
    const { correo, randomNumbers, newPassword } = req.body;

    // Verificar que el correo existe en la base de datos
    const user = await User.findOne({ correo });

    if (!user) {
      return res.status(404).json({ message: "Usuario no encontrado" });
    }

    // Verificar que los números ingresados por el usuario coincidan con los almacenados en el documento del usuario
    if (!user.randomNumbers || !Array.isArray(user.randomNumbers)) {
      return res
        .status(400)
        .json({ message: "Código de seguridad no encontrado para el usuario" });
    }

    if (
      !randomNumbers.every((num, index) => num === user.randomNumbers[index])
    ) {
      return res
        .status(403)
        .json({ message: "Código de seguridad incorrecto" });
    }

    // Si los números son correctos, encriptar la nueva contraseña y actualizarla en el documento del usuario
    const encryptedPassword = await User.encryptPassword(newPassword);
    user.password = encryptedPassword;
    user.randomNumbers = []; // Limpiar los números aleatorios después de usarlos
    await user.save();

    return res.json({ message: "Contraseña cambiada exitosamente" });
  } catch (error) {
    return res.status(500).json({ message: "Error al cambiar la contraseña" });
  }
};

// Eliminar un usuario
export const deleteUser = async (req, res) => {
  try {
    const userId = req.params.userId;

    // Verificar si el usuario existe antes de actualizarlo
    const existingUser = await User.findById(userId);
    if (!existingUser) {
      return res.status(404).json({ message: "Usuario no encontrado." });
    }

    // Actualizar el estado del usuario a "inactivo"
    existingUser.estado = "inactivo";
    await existingUser.save();

    return res
      .status(200)
      .json({ message: "Usuario desactivado exitosamente." });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: "Error al desactivar el usuario." });
  }
};


export const sendRandomNumbers = async (req, res) => {
  try {
    const { correo } = req.body;

    // Verificar que el correo existe en la base de datos
    const user = await User.findOne({ correo });

    if (!user) {
      return res.status(404).json({ message: "Usuario no encontrado" });
    }

    // Generar 6 números aleatorios
    const randomNumbers = Array.from({ length: 6 }, () =>
      Math.floor(Math.random() * 10)
    );

    // Calcular la fecha de expiración (1 hora después de la generación)
    const codeExpiration = new Date();
    codeExpiration.setMinutes(codeExpiration.getMinutes()+10);

    // Guardar los números aleatorios y la fecha de expiración en el documento del usuario
    user.randomNumbers = randomNumbers;
    user.codeExpiration = codeExpiration;
    await user.save();

    const info = await transporter.sendMail({
      from: "rio@rci-colombia.com",
      to: correo, // El correo del usuario
      subject: "Código para restablecer contraseña",
      text: `Tu código de seguridad para restablecer la contraseña es: ${randomNumbers.join("")}`,
    });
    console.log("Correo enviado a:", info.envelope.to);
    console.log("ID del mensaje:", info.messageId);

    return res.status(200).json({ message: "Código de seguridad enviado al correo exitosamente" });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: "Error al enviar el código de seguridad al correo" });
  }
};



// Petición para cambiar la contraseña después de ingresar correctamente los 6 números al azar
export const verifyCode = async (req, res) => {
  try {
    const { correo, randomNumbers } = req.body;

    // Verificar que el correo existe en la base de datos
    const user = await User.findOne({ correo });

    if (!user) {
      return res.status(404).json({ message: "Usuario no encontrado" });
    }

    // Verificar que los números aleatorios ingresados por el usuario y los generados previamente existan y coincidan
    if (
      !randomNumbers ||
      !Array.isArray(randomNumbers) ||
      !user.randomNumbers ||
      !Array.isArray(user.randomNumbers) ||
      !randomNumbers.every((num, index) => num === user.randomNumbers[index])
    ) {
      return res.status(403).json({ message: "Código de seguridad incorrecto" });
    }

    // Verificar si el código ha expirado (1 hora después de la generación)
    const currentTime = new Date();
    if (currentTime > user.codeExpiration) {
      return res
        .status(401)
        .json({
          message: "El código de seguridad ha expirado. Solicita uno nuevo.",
        });
    }

    // Limpiar los números aleatorios y la fecha de expiración después de usarlos
    user.randomNumbers = [];
    user.codeExpiration = undefined;
    await user.save();

    return res.json({ message: "Código de seguridad verificado exitosamente" });
  } catch (error) {
    console.error(error);
    return res
      .status(500)
      .json({ message: "Error al verificar el código de seguridad" });
  }
};


export const changePassword = async (req, res) => {
  try {
    const { correo, newPassword } = req.body;

    // Verificar que el correo existe en la base de datos
    const user = await User.findOne({ correo });

    if (!user) {
      return res.status(404).json({ message: "Usuario no encontrado" });
    }

    // Encriptar la nueva contraseña y actualizarla en el documento del usuario
    const encryptedPassword = await bcrypt.hash(newPassword, 10);
    user.password = encryptedPassword;
    await user.save();

    return res.status(200).json({ message: "Contraseña cambiada exitosamente" });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: "Error al cambiar la contraseña" });
  }
};

