import Oficina from '../models/Oficina.js';
import Visitante from '../models/Visitante.js';
import moment from 'moment';
moment.locale('es-us');


//Petición para crear visitantes

export const createVisitante = async (req, res) => {
  const {
    tipo_documento, documento, nombres, apellidos, sangre, telefono, direccion, eps, arl, enfermedades, alergias
  } = req.body;
  
  try {

    const existingVisitante = await Visitante.findOne({ documento });

    if (existingVisitante) {
      return res.status(400).json({ error: "Ya existe un visitante con el mismo documento." });
    }
    
    const newVisitante = new Visitante({
      tipo_documento , documento, nombres, apellidos, sangre, telefono, direccion, eps, arl, enfermedades, alergias
    });

    const visitantSaved = await newVisitante.save();
    res.status(201).json({message:`Se ha creado a ${visitantSaved.nombres} como visitante.`});

  } catch (error) {
    return res.status(500).json(error);
  }
};

export const getVisitantes = async (req, res) => {
  const visitantes = await Visitante.find();
  res.status(200).json(visitantes);
};

export const getVisitantesById = async (req, res) => {
  const { visitanteId } = req.params;

  try {
    const visitante = await Visitante.findById(visitanteId);

    if (!visitante) {
      return res.status(404).json({ message: "Visitante no encontrado" });
    }

    res.status(200).json(visitante);
  } catch (error) {
    return res.status(500).json({ message: "Error al obtener el visitante", error: error.message });
  }
};

export const updateVisitanteById = async (req, res) => {
  const { visitanteId } = req.params;

  try {
    const updatedVisitante = await Visitante.findByIdAndUpdate(visitanteId, req.body, {
      new: true,
    });

    if (!updatedVisitante) {
      return res.status(404).json({ message: "Visitante no encontrado" });
    }

    const messageSuccess = `El visitante ${updatedVisitante.nombres} ${updatedVisitante.apellidos} se ha actualizado correctamente.`;

    res.status(200).json({ message: messageSuccess, data: updatedVisitante });
  } catch (error) {
    return res.status(500).json({ message: "Error al actualizar el visitante", error: error.message });
  }
};

export const deleteVisitanteById = async (req, res) => {
  const { visitanteId } = req.params;

  try {
    const deletedVisitante = await Visitante.findByIdAndDelete(visitanteId);

    if (!deletedVisitante) {
      return res.status(404).json({ message: "Visitante no encontrado" });
    }

    res.status(204).json();
  } catch (error) {
    return res.status(500).json({ message: "Error al eliminar el visitante", error: error.message });
  }
};


// Reservas visitantes

export const createReservaVisitante = async (req, res) => {
  const { visitanteId } = req.params;
  const {
    fechaReserva,
    responsable_mobilize,
    motivo,
    acudiente,
    tipo_acudiente,
    numero_acudiente
  } = req.body;

  try {
    // Obtener la fecha en formato "YYYY-MM-DD" sin la marca de tiempo
    const fechaReservaFormatted = moment(fechaReserva).startOf('day'); // Quitar la hora

    // Verificar si el visitante ya tiene una reserva en esa fecha
    const existingVisitanteReserva = await Visitante.findOne({
      _id: visitanteId,
      'fechas_reserva.fechaReserva': fechaReservaFormatted,
    });

    if (existingVisitanteReserva) {
      return res.status(400).json({ message: 'El visitante ya tiene una reserva para esta fecha.' });
    }

    // Crear la reserva en el visitante
    const newReserva = {
      fechaReserva: fechaReservaFormatted.toDate(), // Usar la fecha formateada sin la hora
      responsable_mobilize,
      motivo,
      acudiente,
      tipo_acudiente,
      numero_acudiente
    };

    // Buscar o crear la reserva en la oficina
    let oficinaReserva = await Oficina.findOne({
      fecha: fechaReservaFormatted,
    });

    if (!oficinaReserva) {
      const newOficinaReserva = new Oficina({
        fecha: fechaReservaFormatted,
        reservasVisitante: [{ usuario: visitanteId, fechaReserva: fechaReservaFormatted }],
      });

      oficinaReserva = await newOficinaReserva.save();
    } else {
      const existingOficinaVisitanteReserva = oficinaReserva.reservasVisitante.find(
        (reserva) => reserva.usuario.toString() === visitanteId
      );

      if (existingOficinaVisitanteReserva) {
        return res.status(400).json({ message: 'El visitante ya tiene una reserva en la oficina para esta fecha.' });
      }

      oficinaReserva.reservasVisitante.push({ usuario: visitanteId, fechaReserva: fechaReservaFormatted });
      await oficinaReserva.save();
    }

    // Asociar la oficina en la reserva del visitante
    newReserva.oficina = oficinaReserva._id;

    // Actualizar las fechas_reserva del visitante
    await Visitante.findByIdAndUpdate(visitanteId, { $push: { fechas_reserva: newReserva } });

    return res.status(201).json({ message: 'Reserva creada exitosamente.' });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: 'Error al crear la reserva.' });
  }
};




export const deleteReservaVisitante = async (req, res) => {
  try {
    const { visitanteId, fechaReserva } = req.params;

    // Buscar el visitante por ID
    const visitante = await Visitante.findById(visitanteId);

    if (!visitante) {
      return res.status(404).json({ message: 'Visitante no encontrado.' });
    }

    const fechaReservaToDelete = moment.utc(fechaReserva).startOf('day').format('YYYY-MM-DD');

    // Filtrar las fechas de reserva para mantener solo las diferentes a la fecha que se desea eliminar
    const updatedReservasVisitante = visitante.fechas_reserva.filter(
      (reserva) => moment(reserva.fechaReserva).format('YYYY-MM-DD') !== fechaReservaToDelete
    );

    if (updatedReservasVisitante.length === visitante.fechas_reserva.length) {
      return res.status(400).json({ message: 'No se encontró reserva para esta fecha.' });
    }

    visitante.fechas_reserva = updatedReservasVisitante;

    // Guardar los cambios en el visitante
    await visitante.save();

    // Eliminar la referencia de reserva en el arreglo reservasVisitante del documento de Oficina
    const oficina = await Oficina.findOne({ fecha: new Date(fechaReservaToDelete) });
    if (oficina) {
      oficina.reservasVisitante = oficina.reservasVisitante.filter(
        (reserva) => moment(reserva.fechaReserva).format('YYYY-MM-DD') !== fechaReservaToDelete
      );
      await oficina.save();
    }

    // Eliminar también la referencia de reserva en la colección de Oficina
    await Oficina.findOneAndUpdate(
      { 'reservasVisitante.usuario': visitanteId, 'reservasVisitante.fechaReserva': new Date(fechaReservaToDelete) },
      { $pull: { 'reservasVisitante': { usuario: visitanteId, fechaReserva: new Date(fechaReservaToDelete) } } }
    );

    return res.status(200).json({ message: 'Reserva eliminada exitosamente.' });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: 'Error al eliminar la reserva.' });
  }
};






export const updateReservaVisitante = async (req, res) => {
  try {
    const { visitanteId, fechaReserva } = req.params;

    // Formatear la fecha de reserva para compararla
    const formattedFechaReserva = moment.utc(fechaReserva).startOf('day').format('YYYY-MM-DD');

    // Buscar el visitante por ID
    const visitante = await Visitante.findById(visitanteId);

    if (!visitante) {
      return res.status(404).json({ message: 'Visitante no encontrado.' });
    }

    // Buscar la reserva en el arreglo fechas_reserva
    const reserva = visitante.fechas_reserva.find(
      (reserva) => moment(reserva.fechaReserva).format('YYYY-MM-DD') === formattedFechaReserva
    );

    if (!reserva) {
      return res.status(404).json({ message: 'No se encontró una reserva para la fecha especificada.' });
    }

    // Actualizar los datos de la reserva con los valores del cuerpo de la solicitud
    reserva.responsable_mobilize = req.body.responsable_mobilize;
    reserva.motivo = req.body.motivo;
    reserva.acudiente = req.body.acudiente;
    reserva.tipo_acudiente = req.body.tipo_acudiente;
    reserva.numero_acudiente = req.body.numero_acudiente;

    // Guardar los cambios en el visitante
    await visitante.save();

    return res.status(200).json({ message: 'Reserva actualizada exitosamente.' });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: 'Error al actualizar la reserva.' });
  }
};



