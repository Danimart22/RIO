import mongoose from "mongoose";
import { MONGODB_URI } from "./config.js";

try {
  const db = await mongoose.connect(MONGODB_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
    serverSelectionTimeoutMS: 5000
  });
  console.log(
    "La base de datos '", db.connection.name, "' está conectada",
  );
} catch (error) {
  console.error(error.message);
}
