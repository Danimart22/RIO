import 'dotenv/config'
import app from "./app.js";
import cron from "node-cron"
import './database.js'
import { PORT } from "./config.js";
import "./libs/initialSetup.js";
import { backupMongoDB, autodelete } from "./backup.js";

app.listen(PORT);
console.log("Servidor en el puerto", app.get("port"));

//Programación de ejecucion
cron.schedule('1 14 * * * ', () => {backupMongoDB()
});
cron.schedule('1 19 * * * ', () => {backupMongoDB();
  autodelete();
});