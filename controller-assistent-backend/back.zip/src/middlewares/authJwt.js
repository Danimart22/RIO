import jwt from "jsonwebtoken";
import { SECRET } from "../config.js";
import User from "../models/User.js";
import Roles from "../models/Roles.js";

export const verifyToken = async (req, res, next) => {
  try {
    const token = req.headers["x-access-token"];

    if (!token) {
      return res.status(403).json({ message: "No se ha otorgado token" });
    }

    const decoded = jwt.verify(token, SECRET);
    req.userId = decoded.id;

    const user = await User.findById(req.userId, { password: 0 });
    if (!user) {
      return res.status(404).json({ message: "No se encontró usuario" });
    }

    next();
  } catch (error) {
    return res
      .status(401)
      .json({ message: "No cuentas con autorizacion para esta acción" });
  }
};

export const userAdmin = async (req, res, next) => {
  try {
    const user = await User.findById(req.userId);
    const roles = await Roles.find({ _id: { $in: user.roles } });

    for (let i = 0; i < roles.length; i++) {
      if (roles[i].nombre === "admin") {
        next();
        return;
      }
    }
    return res
      .status(403)
      .json({ message: "Se requiere ser de Admin para realizar esta accion" });
  } catch (error) {
    console.log(error);
    return res.status(500).send({ message: error });
  }
};

export const userEmpleado = async (req, res, next) => {
  try {
    const user = await User.findById(req.userId);
    const roles = await Roles.find({ _id: { $in: user.roles } });

    for (let i = 0; i < roles.length; i++) {
      if (roles[i].nombre === "empleado") {
        next();
        return;
      }
    }
    return res
      .status(403)
      .json({ message: "Se requiere ser un Empleado para realizar esta accion" });
  } catch (error) {
    console.log(error);
    return res.status(500).send({ message: error });
  }
};


export const userRRHH = async (req, res, next) => {
  try {
    const user = await User.findById(req.userId);
    const roles = await Roles.find({ _id: { $in: user.roles } });

    for (let i = 0; i < roles.length; i++) {
      if (roles[i].nombre === "RRHH") {
        next();
        return;
      }
    }
    return res
      .status(403)
      .json({ message: "Se requiere ser de RRHH para realizar esta accion" });
  } catch (error) {
    console.log(error);
    return res.status(500).send({ message: error });
  }
};

export const userBrigadista = async (req,res,next) => {
  try {
    const user = await User.findById(req.userId);

      if (user.brigadista === "Si") {
        next();
        return;
      }
    return res
      .status(403)
      .json({ message: "Se requiere ser de Brigadista para realizar esta accion" });
  } catch (error) {
    console.log(error);
    return res.status(500).send({ message: error });
  }
}

export const userPorteria = async (req, res, next) => {
  try {
    const user = await User.findById(req.userId);
    const roles = await Roles.find({ _id: { $in: user.roles } });

    for (let i = 0; i < roles.length; i++) {
      if (roles[i].nombre === "porteria") {
        next();
        return;
      }
    }
    return res
      .status(403)
      .json({ message: "Se requiere ser de Porteria para realizar esta accion" });
  } catch (error) {
    console.log(error);
    return res.status(500).send({ message: error });
  }
};

export const userTI = async (req, res, next) => {
  try {
    const user = await User.findById(req.userId);
    const roles = await Roles.find({ _id: { $in: user.roles } });

    for (let i = 0; i < roles.length; i++) {
      if (roles[i].nombre === "TI") {
        next();
        return;
      }
    }
    return res
      .status(403)
      .json({ message: "Se requiere ser de TI para realizar esta accion" });
  } catch (error) {
    console.log(error);
    return res.status(500).send({ message: error });
  }
};

export const userReportado = async (req, res, next) => {
  try {
    const user = await User.findById(req.userId);
    const roles = await Roles.find({ _id: { $in: user.roles } });

    for (let i = 0; i < roles.length; i++) {
      if (roles[i].nombre === "TI"||roles[i].nombre === "RRHH") {
        next();
        return;
      }
    }
    return res
      .status(403)
      .json({ message: "Se requiere ser de TI o RRHH para realizar esta accion" });
  } catch (error) {
    console.log(error);
    return res.status(500).send({ message: error });
  }
};