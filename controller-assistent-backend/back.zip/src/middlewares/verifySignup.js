import {ROLES} from '../models/Roles.js'
import User from '../models/User.js'

export const checkDuplicateUser = async (req, res, next) =>{
    const user = await User.findOne({documento: req.body.documento })
    if(user) return res.status(400).json({message: "Ya hay alguien con ese documento de identidad"})

    const correo = await User.findOne({correo: req.body.correo})
    if(correo) return res.status(400).json({message: "Ya hay alguien con ese correo registrado"})

    next();
}   


export const checkRolesExisted= (req, res, next) =>{
    if (req.body.roles){
        for(let i=0; i< req.body.roles.length; i++){
            if (!ROLES.includes(req.body.roles[i])){
                return res.status(400).json({
                    message: `El rol ${req.body.roles[i]} no existe`
                })
            }
        }
    }

    next();
}
