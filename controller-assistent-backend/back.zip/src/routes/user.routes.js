import { Router } from 'express';
const router = Router();

import * as userCtrl from '../controllers/user.controller.js';
import { authJwt, verifySignup } from '../middlewares/index.js';

// Rutas para usuarios

// Crear un nuevo usuario
router.post('/', [authJwt.verifyToken, authJwt.userRRHH, verifySignup.checkRolesExisted], userCtrl.createUser);

// Obtener todos los usuarios activos
router.get('/', [authJwt.verifyToken, authJwt.userRRHH], userCtrl.getUsers);

router.get('/responsables', [authJwt.verifyToken, authJwt.userEmpleado], userCtrl.getUsers);

// Obtener todos los usuarios (incluyendo inactivos)
router.get('/all', [authJwt.verifyToken, authJwt.userAdmin], userCtrl.getAllUsers);

// Obtener un usuario por su ID
router.get('/:userId', [authJwt.verifyToken, authJwt.userEmpleado], userCtrl.getUserById);

// Actualizar un usuario
router.put('/:userId', [authJwt.verifyToken, authJwt.userEmpleado], userCtrl.updateUser);

router.put('/restPassword/:id', [authJwt.verifyToken, authJwt.userEmpleado], userCtrl.updatePassword);

// Eliminar un usuario (solo lo deshabilita)
router.put('/delete/:userId', [authJwt.verifyToken, authJwt.userRRHH], userCtrl.deleteUser);


// Restablecimiento de contraseña
router.post("/sendNumbers", userCtrl.sendRandomNumbers);
router.post("/verifyCode", userCtrl.verifyCode);
router.post("/changePassword", userCtrl.changePassword);


// Obtener todos los usuarios activos cuyo rol es igual a EMPLEADOS
router.get('/visitantes', [authJwt.verifyToken, authJwt.userPorteria], userCtrl.getUsersEmpleados);


export default router;
